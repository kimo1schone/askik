

www.kd1s.com مقدم من موقع

Mass Looker ,it’s a console-based script created for massvoting (mass poll voting) and masslooking stories

# Features
 Author credits : nthanfp
 Modified by @zns Follow on Instagram www.instagram.com/zns/ and
 Subscribe Youtube Channel for more videos https://www.youtube.com/channel/UCS9cnL2cj_9jDEi3Cc1mnAA

  - Views Stories
  - Question Answer
  - Poll Voting
  - Emoji Slider
  
# Uses 
   - Unlimited real followers
   - Unlimited real likes
   - Increasing profile visits
   - Incredible reach
   
# Installation

MassLooker requires [PHP](https://www.php.net/) 5.6 to run.

```sh
طريقة التركيب 

Follow These Steps for Installation

pkg install php

pkg install git

pkg install unzip

pkg install mc

git clone https://github.com/xznsx/kd1s

cd kd1s

unzip kd1s.zip

cd kd1s 

php login.php

php run.php


